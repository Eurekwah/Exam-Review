#include <iostream>
#include <string>
#include <cstdio>
#include <cstring>
#include <iomanip>

using namespace std;

/*������ѧ����Ϣ*/
struct inf
{
    int number;
    int cla;
    string name;
    float gr1, gr2, gr3;
    float allgr;
};

struct inf stu[7] = {{10001, 11, "Zhang", 99.5, 88.5, 89.5},{10002, 12, "Yang", 77.9, 56.5, 87.5},
                    {10003, 11, "Liang", 92.5, 99.0, 60.5},{10004, 11, "Cai", 89.6, 56.9,90.5},{10005, 14, "Fu", 55.6, 67.9, 98.9},
                    {10006, 12, "Mao", 22.1, 45.9, 99.2},{10007, 13, "Zhan", 35.6, 67.9, 88.0}};
/*ѧ����Ϣ�������*/

/*������������*/
void sort()
{
    for (int i = 1; i < 7; i++)
    {
        for (int j = 0; j < i; j++)
        {
            if (stu[j + 1].cla < stu[j].cla)
            {
                struct inf tmp;
                tmp = stu[j + 1];
                stu[j + 1] = stu[j];
                stu[j] = tmp;
            }
            if (stu[j + 1].allgr > stu[j].allgr && stu[j + 1].cla == stu[j].cla)
            {
                struct inf tmp;
                tmp = stu[j + 1];
                stu[j + 1] = stu[j];
                stu[j] = tmp;
            }
        }
    }
}
/*����������*/

/*�����ǵ�һ������*/
void input12(int a[])
{
    scanf("%d-%d", &a[0], &a[1]);
}

void search1(int a, int b)
{
    for (int i = a; i <= b; i++)
    {
        for (int j = 0; j < 7; j++)
        {
            if (stu[j].cla == i)
            {
                cout << stu[j].number << ' ' << stu[j].cla << ' ' << stu[j].name << ' ' << stu[j].gr1 << ' ' << stu[j].gr2 << ' ' << stu[j].gr3 << endl;
            }
        }
    }
}
/*��һ����������*/

/*�����ǵڶ�������*/
void search2(int a, int b)
{
    for (int j = 0; j < 7; j++)
    {
        for (int i = a; i <= b; i++)
        {
            if (stu[j].number == i)
            {
                cout << stu[j].number << ' ' << stu[j].cla << ' ' << stu[j].name << ' ' << stu[j].gr1 << ' ' << stu[j].gr2 << ' ' << stu[j].gr3 << endl;
            }
        }
    }
}
/*�ڶ�����������*/

/*�����ǵ���������*/
void input3(char *b)
{
    string input;
    cin >> input;
    for (int i = 0; i < 3; i++)
    {
        if (input[i] != '*')
        {
            b[i] = input[i];
        }
    }
}

void search3(char *b, int a)
{
    if (a = 1)
    {
        for (int i = 0; i < 7; i++)
        {
            if (stu[i].name[0] == b[0])
            {
                cout << stu[i].number << ' ' << stu[i].cla << ' ' << stu[i].name << ' ' << stu[i].gr1 << ' ' << stu[i].gr2 << ' ' << stu[i].gr3 << endl;
            }
        }
    }
    else if (a = 2)
    {
        for (int i = 0; i < 7; i++)
        {
            if (stu[i].name[0] == b[0] && stu[i].name[1] == b[1])
            {
                cout << stu[i].number << ' ' << stu[i].cla << ' ' << stu[i].name << ' ' << stu[i].gr1 << ' ' << stu[i].gr2 << ' ' << stu[i].gr3 << endl;
            }
        }
    }
}
/*��������������*/

/*�����ǵ���������*/
int input4()
{
    int a;
    cin >> a;
    return a;
}

void search4(int a)
{
    for (int i = 0; i < 7; i++)
    {
        if (stu[i].allgr >= a)
        {
            cout << stu[i].number << ' ' << stu[i].cla << ' ' << stu[i].name << ' ' << stu[i].gr1 << ' ' << stu[i].gr2 << ' ' << stu[i].gr3 << endl;
        }
    }
}
/*��������������*/

/*������������ʼ*/
void input5(int *a,int b[])
{
    cin >> *a;
    scanf(".%d-%d", &b[0], &b[1]);
}

void search5(int a, int b, int c)
{
    for (int i = 0; i < 7; i++)
    {
        if (stu[i].cla == a)
        {
            for (int j = b; j <= c; j++)
            {
                if (stu[i].number == j)
                {
                    cout << stu[i].number << ' ' << stu[i].cla << ' ' << stu[i].name << ' ' << stu[i].gr1 << ' ' << stu[i].gr2 << ' ' << stu[i].gr3 << endl;
                }
            }
        }
    }
}
/*��������������*/

int main()
{
    for (int i = 0; i < 7; i++)
    {
        stu[i].allgr = stu[i].gr1 + stu[i].gr2 + stu[i].gr3;
    }//���ܳɼ�
    sort();//����
    int tp;
    int a[3];
    char b[4];
    int in4;
    int incla5, innumber[2];
    int *in5 = &incla5;
    cin >> tp;
    cout << setiosflags(ios::fixed)<<setprecision(1);
    switch (tp)
    {
        case 1:input12(a); search1(a[0], a[1]); break;
        case 2:input12(a); search2(a[0], a[1]); break;
        case 3:input3(b);  search3(b,strlen(b));break;
        case 4:in4 = input4();     search4(in4);break;
        case 5:input5(in5, innumber);search5(incla5,innumber[0],innumber[1]);break;
    }
    return 0;
}
