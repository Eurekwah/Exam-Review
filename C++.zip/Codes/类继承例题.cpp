#include <iostream>

using namespace std;

class A {
public:
    /*virtual*/ void f1()
    {
        cout<< "A1" << endl;
        f3();
    }
    /*virtual*/ void f3()
    {
        cout<< "A3" << endl;
    }
};
class B : public A
{
public:
    /*virtual*/ void f1()
    {
        A::f1();
        cout<< "B1" << endl;
    }
    void f3()
    {
        cout<< "B3" << endl;
    }
};

int main()
{
    B* a = new B();
    a->f3();
    return 0;
}
