#include <iostream>

using namespace std;

struct input
{
    string name;
    int time = 1;
};

struct input animal[4000000];

int main()
{
    int n, a = 0, b = 0, n1 = 0, n2 = 0, i;
    cin >> n;
    for (i = 0; i < n; i++)
    {
        cin >> animal[i].name;
        for (int j = 0; j < i; j++)
        {
            if (animal[i].name == animal[j].name)
            {
                animal[j].time++;
                break;
            }
        }
    }
    for (int j = 0; j < n; j++)
    {
        if (animal[j].time == a)
        {
            b = animal[j].time;
            n2 = j;
        }
        if (animal[j].time > a)
        {
            a = animal[j].time;
            n1 = j;
        }
    }
    if (a > b)
    {
        cout << animal[n1].name << ' ' << animal[n1].time;
    }
    if (a == b)
    {
        cout << animal[n1].name << ' ' << animal[n1].time << ' ' << animal[n2].name << ' ' << animal[n2].time;
    }
    return 0;
}
