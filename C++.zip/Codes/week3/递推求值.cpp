#include <iostream>

using namespace std;

long long f(int n, int a, int b, int c);

int f1, f2;

int mod(long long a, int b)
{
    int n = -10;
    while (n * b <= a)
    {
        n++;
    }
    return a - (n - 1) * b;
}

int main()
{
    int a, b, c, n;
    cin >> f1 >> f2 >> a >> b >> c >> n;
    int output = mod(f(n , a, b, c), 1000007);
    cout << output;
    return 0;
}

long long f(int n,int a, int b, int c)
{

    if (n > 2)
        return a * f(n - 2, a, b, c) + b * f(n - 1, a, b,c) + c;
    else if (n == 1)
        return f1;
    else if (n == 2)
        return f2;
}
