#include<iostream>

using namespace std;

int hanoi(int x)
{
	long long result;
	if (x == 1)
		result = 1;
	if (x > 1)
		result = 2 * hanoi(x - 1) + 1;
	if (result >= 1000000)
	{
		return result % 1000000;
	}
	else
		return result;
}

int main()
{
	int m;
	cin >> m;
	cout << hanoi(m);
	return 0;
}
