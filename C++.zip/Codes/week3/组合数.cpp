#include <iostream>

using namespace std;

void combination(int n, int r, int prev)
{
    if (r == 0)
    {
        cout << endl;
        return;
    }
    bool first = true;
    for (int i = n; i > r-1; i--)
    {
        if (prev && !first) cout << prev;
        cout << i;
        first = false;
       combination(i-1, r-1, prev * 10 + i);
    }
}

int main()
{
    int n, r;
    cin >> n >> r;
    combination(n, r, 0);
    return 0;
}
