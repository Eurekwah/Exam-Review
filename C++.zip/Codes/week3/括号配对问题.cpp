#include <iostream>
#include <cstring>

using namespace std;

int main()
{
    char input[10000];
    cin.getline(input, 10000);
    const int n = strlen(input);
    if (input[n - 1] == '[' || input[n - 1] == '(')
    {
        cout << "No";
        return 0;
    }
    char Stack[n];
    int i, j;
    for (i = 0, j = 0; i < n; i++)
    {
        if (input[i] == '[' || input[i] == '(')
        {
            Stack[j + 1] = input[i];
            j++;
        }
        else if (input[i] == ']' || input[i] == ')')
        {
           if (i == 0)
           {
               break;
           }
           else if (i > 0)
           {
               if (input[i] == ']')
               {
                   if (Stack[j] == '[')
                   {
                       j--;
                   }
                   else break;
               }
               if (input[i] == ')')
               {
                   if (Stack[j] == '(')
                   {
                       j--;
                   }
                   else break;
               }
           }
        }
    }
    if (i == n)
        {
            if (j == 0)
            {
                cout << "Yes";
            }
            else cout << "No";
        }
    else cout << "No";
    return 0;
}
