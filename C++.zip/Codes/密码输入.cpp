#include <conio.h>
#include <iostream>
#include <string>

using namespace std;

int main()
{
    string password;
    char c;
    cout << "please input password: ";
    while (true)
    {
        c = getch();
        if (c == char(13))
            break;
        password += c;
        cout << '*';
    }
    cout << endl << password;
    return 0;
}
