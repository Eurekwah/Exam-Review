#include <iostream>
#include <iomanip>
#include <string>
#include <cctype>
#include <cstdlib>
#include <cstring>
#include <algorithm>
#include <utility>

using namespace std;

void func(int i);
void menu();
int stunum = 0; //student number

class Information
{
  private:
    int Id, cla;
    char name[15];
    float score1, score2, score3;

  public:
    Information *next;
    Information();
    Information(Information &a); //copy
    ~Information();
    float allscore()
    {
        return score1 + score2 + score3;
    };
    friend istream &operator>>(istream &, Information *);
    friend ostream &operator<<(ostream &, Information *);
    friend void change(Information *pre);
    friend void input();
    friend void deleteStu();
    friend void rankStu();
    friend void selectStu();
    friend void outputAllstu();
};

Information *head = new Information;
Information *last = new Information;

/*Class definition*/
Information::Information()
{
    strcpy(name, "null");
    Id = 0;
    cla = 0;
    score1 = 0;
    score2 = 0;
    score3 = 0;
    next = last;
}

Information::Information(Information &a)
{
    Id = a.Id;
    cla = a.cla;
    score1 = a.score1;
    score2 = a.score2;
    score3 = a.score3;
    strcpy(name, a.name);
    next = a.next;
}

Information::~Information()
{
    stunum--;
}

istream &operator>>(istream &input, Information *a)
{
    cout << "Id ";
    input >> a->Id;
    cout << "class ";
    input >> a->cla;
    cout << "name ";
    input >> a->name;
    cout << "score1 ";
    input >> a->score1;
    cout << "score2 ";
    input >> a->score2;
    cout << "score3 ";
    input >> a->score3;
    stunum++;
    return input;
}

ostream &operator<<(ostream &output, Information *a)
{
    output << a->Id << ',' << a->cla << ',' << a->name << ','
           << a->score1 << ',' << a->score2 << ',' << a->score3 << ',' << a->allscore() << endl;
    return output;
}

Information *inputpre = head;
void input()
{
    string choice = "yes";
    for (; choice == "yes"; stunum++)
    {
        Information *p = new Information;
        cin >> p;
        inputpre->next = p;
        inputpre = p;
        p->next = last;
        cout << "continue?\n";
        cin >> choice;
    }
    menu();
}

/*change student*/
void change(Information *pre)
{
    Information *m = pre->next;
    swap(m->Id, m->next->Id);
    swap(m->cla, m->next->cla);
    swap(m->next, m->next->next);
    swap(m->score1, m->next->score1);
    swap(m->score2, m->next->score2);
    swap(m->score3, m->next->score3);
}

/*delete student*/
void deleteStu()
{
    int delNumber;
    char delName[10];
    string input;
    cin >> input;
    for (int i = 0; i < 10; i++)
    {
        delName[i] = input[i];
    }
    if (isdigit(input[0])) //����Ϊѧ�ţ�done��
    {
        delNumber = atoi(delName);
        Information *pre = head;
        Information *p = head->next;
        while (p->next != NULL)
        {
            if (p->Id == delNumber)
            {
                pre->next = p->next;
                p = p->next;
                stunum--;
            }
            else
            {
                pre = p;
                p = p->next;
            }
        };
    }
    else if (islower(input[0])) //����Ϊ���֣�done��
    {
        Information *pre = head;
        Information *p = head->next;
        while (p->next != NULL)
        {
            if (strcmp(p->name, delName) == 0)
            {
                pre->next = p->next;
                p = p->next;
                stunum--;
            }
            else
            {
                pre = p;
                p = p->next;
            }
        };
    }
    Information *p = head->next;
    while (p->next != NULL)
    {
        cout << p;
        p = p->next;
    }
    cout << "continue?\n";
    string choice;
    cin >> choice;
    if (choice == "yes")
        deleteStu();
    else
        menu();
}
/*select student*/
void selectStu()
{
    int input, j = 0;
    cin >> input;
    Information *p = head->next;
    while (p->next != NULL)
    {
        if (p->Id == input || p->cla == input)
            cout << p;
        p = p->next;
        j++;
    }
    if (j == 0)
        cout << " there is no eligible student \n";
    cout << "continue?\n";
    string choice;
    cin >> choice;
    if (choice == "yes")
        selectStu();
    else
        menu();
}

/*rank student*/
void rankStu()
{
    for (int i = 0; i < stunum - 1; i++)
    {
        for (int j = 0; j <= i; j++)
        {
            Information *m = head;
            if (m->next->cla > m->next->next->cla)
                change(m);
            if (m->next->allscore() < m->next->next->allscore() && m->next->cla == m->next->next->cla)
                change(m);
            m = m->next;
        }
    }
    Information *m = head;
    for (int i = 0; i < stunum; i++)
    {
        cout << m->next;
        m = m->next;
    }
    menu();
}
/*output all students*/
void outputAllstu()
{
    Information *p = head->next;
    while (p->next != NULL)
    {
        cout << p;
        p = p->next;
    }
    menu();
}

/*output menu*/
void menu()
{
    cout << "1.input\n"
         << "2.delete\n"
         << "3.select\n"
         << "4.order\n"
         << "5.output\n"
         << "6.quit\n"
         << "please input your option\n";
    int mode;
    cin >> mode;
    func(mode);
}

/*choose function*/
void func(int i)
{
    switch (i)
    {
    case 1:
        input();
    case 2:
        deleteStu();
    case 3:
        selectStu();
    case 4:
        rankStu();
    case 5:
        outputAllstu();
    case 6:
        exit(0);
    }
}

int main()
{
    last->next = NULL;
    cout << setiosflags(ios::fixed) << setprecision(1);
    menu();
    return 0;
}
