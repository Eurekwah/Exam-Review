#include <iostream>
#include <iomanip>
#include <string>
#include <cctype>
#include <cstdlib>
#include <cstring>
#include <algorithm>
#include <utility>
#include <vector>

using namespace std;

void deleteStu();
void selectStu();
void rankStu();
void menu();
void input();
void outputAllstu();

class Information
{
  private:
    int Id, klass;
    char name[15];
    float score1, score2, score3;
    float allscore() const
    {
        return score1 + score2 + score3;
    };

  public:
    Information();
    Information(Information const &);
    int getId() const
    {
        return Id;
    }
    int getKlass() const
    {
        return klass;
    }
    char const *getName() const
    {
        return name;
    }
    friend istream &operator>>(istream &, Information &);
    friend ostream &operator<<(ostream &, Information const &);
    friend bool operator<(Information const &, Information const &);
};

//class defination

Information::Information()
{
    Id = 0;
    klass = 0;
    strcpy(name, "null");
    score1 = 0;
    score2 = 0;
    score3 = 0;
}

Information::Information(Information const &a)
{
    Id = a.Id;
    klass = a.klass;
    score1 = a.score1;
    score2 = a.score2;
    score3 = a.score3;
    strcpy(name, a.name);
}

istream &operator>>(istream &input, Information &a)
{
    cout << "Id ";
    input >> a.Id;
    cout << "class ";
    input >> a.klass;
    cout << "name ";
    input >> a.name;
    cout << "score1 ";
    input >> a.score1;
    cout << "score2 ";
    input >> a.score2;
    cout << "score3 ";
    input >> a.score3;
    return input;
}

ostream &operator<<(ostream &output, Information const &a)
{
    output << a.Id << ','
           << a.klass << ','
           << a.name << ','
           << a.score1 << ','
           << a.score2 << ','
           << a.score3 << ','
           << a.allscore()
           << endl;
    return output;
}

bool operator<(Information const &b, Information const &a)
{
    if (b.klass < a.klass)
        return true;
    if (b.klass == a.klass && b.allscore() > a.allscore())
        return true;
    else
        return false;
}

vector<Information> students;

void input()
{
    Information student;
    cin >> student;
    students.push_back(student);
    cout << "continue?\n";
    string choice;
    cin >> choice;
    if (choice == "yes")
        input();
    else
        menu();
}

void deleteStu()
{
    int delNumber;
    char delName[10];
    string input;
    cin >> input;
    for (int i = 0; i < 10; i++)
    {
        delName[i] = input[i];
    }
    if (isdigit(input[0]))
    {
        delNumber = atoi(delName);
        for (int i = 0; i < students.size(); i++)
        {
            if (students[i].getId() == delNumber)
            {
                students.erase(students.begin() + i);
            }
        }
    }
    else if (islower(input[0]))
    {
        for (int i = 0; i < students.size(); i++)
        {
            if (strcmp(students[i].getName(), delName) == 0)
            {
                students.erase(students.begin() + i);
            }
        }
    }
    for (int i = 0; i < students.size(); i++)
    {
        cout << students[i];
    }
    cout << "continue?\n";
    string choice;
    cin >> choice;
    if (choice == "yes")
        deleteStu();
    else
        menu();
}

void selectStu()
{
    int input, j = 0;
    cin >> input;
    for (int i = 0; i < students.size(); i++)
    {
        if (input == students[i].getId() || input == students[i].getKlass())
        {
            cout << students[i];
            j++;
        }
    }
    if (j == 0)
        cout << " there is no eligible student \n";
    cout << "continue?\n";
    string choice;
    cin >> choice;
    if (choice == "yes")
        selectStu();
    else
        menu();
}

void rankStu()
{
    sort(students.begin(), students.end());
    outputAllstu();
    menu();
}

void outputAllstu()
{
    for (int i = 0; i < students.size(); i++)
        cout << students[i];
    menu();
}

void func(int i)
{
    switch (i)
    {
    case 1:
        input();
    case 2:
        deleteStu();
    case 3:
        selectStu();
    case 4:
        rankStu();
    case 5:
        outputAllstu();
    case 6:
        exit(0);
    }
}

void menu()
{
    cout << "1.input\n"
         << "2.delete\n"
         << "3.select\n"
         << "4.order\n"
         << "5.output\n"
         << "6.quit\n"
         << "please input your option\n";
    int mode;
    cin >> mode;
    func(mode);
}

int main()
{
    cout << setiosflags(ios::fixed) << setprecision(1);
    menu();
    return 0;
}
