#include <iostream>
#include <iomanip>
#include <string>
#include <cctype>
#include <cstdlib>
#include <cstring>
#include <algorithm>
#include <utility>

using namespace std;

void func(int i);
void menu();
void input1();
void deleteStu();
void selectStu();
void rankStu();
void outputAllstu();
int stunum = 0; //ѧ������

struct Information
{
    int Id, cla;
    char name[10];
    float score1, score2, score3;
    float allscore()
    {
        return score1 + score2 + score3;
    };
    Information *next;
};

struct Information *head = new Information;
struct Information *last = new Information;

void change(Information *pre)
{
    Information *m = pre->next;
    swap(m->Id, m->next->Id);
    swap(m->cla, m->next->cla);
    swap(m->next, m->next->next);
    swap(m->score1, m->next->score1);
    swap(m->score2, m->next->score2);
    swap(m->score3, m->next->score3);
}

void outputOnestu(Information *p)
{
    cout << p->Id << ',' << p->cla << ',' << p->name << ',' << p->score1 << ','
         << p->score2 << ',' << p->score3 << ',' << p->allscore() << endl;
}

/*������ʵ��ѡ���ܵĺ���*/
void func(int i)
{
    switch (i)
    {
    case 1:
        input1();
    case 2:
        deleteStu();
    case 3:
        selectStu();
    case 4:
        rankStu();
    case 5:
        outputAllstu();
    case 6:
        exit(0);
    }
}

/*�����ǵ�һ��ܣ��˵�����Ϣ¼�루done��*/
void menu() /*����˵�*/
{
    cout << "1.input\n"
         << "2.delete\n"
         << "3.select\n"
         << "4.order\n"
         << "5.output\n"
         << "6.quit\n"
         << "please input your option\n";
    int mode;
    cin >> mode;
    func(mode);
}
Information *inputpre = head;
7void input1()
{
    string choice = "yes";
    for (; choice == "yes"; stunum++)
    {
        Information *p = new Information;
        cout << "Id ";
        cin >> p->Id;
        cout << "class ";
        cin >> p->cla;
        cout << "name ";
        cin >> p->name;
        cout << "score1 ";
        cin >> p->score1;
        cout << "score2 ";
        cin >> p->score2;
        cout << "score3 ";
        cin >> p->score3;
        inputpre->next = p;
        inputpre = p;
        p->next = last;
        cout << "continue?\n";
        cin >> choice;
    }
    menu();
}

/*�����ǵڶ���ܣ�ɾ��ѧ����done��*/
void deleteStu()
{
    int delNumber;
    char delName[10];
    string input;
    cin >> input;
    for (int i = 0; i < 10; i++)
    {
        delName[i] = input[i];
    }
    if (isdigit(input[0])) //����Ϊѧ�ţ�done��
    {
        delNumber = atoi(delName);
        Information *pre = head;
        Information *p = head->next;
        while (p->next != NULL)
        {
            if (p->Id == delNumber)
            {
                pre->next = p->next;
                p = p->next;
                stunum--;
            }
            else
            {
                pre = p;
                p = p->next;
            }
        };
    }
    else if (islower(input[0])) //����Ϊ���֣�done��
    {
        Information *pre = head;
        Information *p = head->next;
        while (p->next != NULL)
        {
            if (strcmp(p->name, delName) == 0)
            {
                pre->next = p->next;
                p = p->next;
                stunum--;
            }
            else
            {
                pre = p;
                p = p->next;
            }
        };
    }
    Information *p = head->next;
    while (p->next != NULL)
    {
        outputOnestu(p);
        p = p->next;
    }
    cout << "continue?\n";
    string choice;
    cin >> choice;
    if (choice == "yes")
        deleteStu();
    else
        menu();
}

/*�����ǵ�����ܣ�ѡ��ѧ������*/
void selectStu()
{
    int input, j = 0;
    cin >> input;
    Information *p = head->next;
    while (p->next != NULL)
    {
        if (p->Id == input || p->cla == input)
            outputOnestu(p);
        p = p->next;
        j++;
    }
    if (j == 0)
        cout << " there is no eligible student \n";
    cout << "continue?\n";
    string choice;
    cin >> choice;
    if (choice == "yes")
        selectStu();
    else
        menu();
}

/*�����ǵ�����ܣ���Ϣ���򣨣�*/
void rankStu()
{
    for (int i = 0; i < stunum - 1; i++)
    {
        for (int j = 0; j <= i; j++)
        {
            Information *m = head;
            if (m->next->cla > m->next->next->cla)
                change(m);
            if (m->next->allscore() < m->next->next->allscore() && m->next->cla == m->next->next->cla)
                change(m);
            m = m->next;
        }
    }
    Information *m = head;
    for (int i = 0; i < stunum; i++)
    {
        outputOnestu(m->next);
        m = m->next;
    }
    menu();
}

/*�����ǵ�����ܣ����ѧ����Ϣ����*/
void outputAllstu()
{
    Information *p = head->next;
    while (p->next != NULL)
    {
        outputOnestu(p);
        p = p->next;
    }
    menu();
}

int main()
{
    last->next = NULL;
    cout << setiosflags(ios::fixed) << setprecision(1);
    menu();
    return 0;
}
