#include <iostream>
#include <iomanip>
#include <string>
#include <cctype>
#include <cstdlib>
#include <cstring>
#include <algorithm>
#include <utility>

using namespace std;

void func(int i);
void menu();
void input1();
void deleteStu();
void outputOnestu(int n);
void selectStu();
void rankStu();
void outputAllstu();
int stunum = 0;

class Information
{
  public:
    int Id, cla;
    char name[10];
    float score1, score2, score3;
    float allscore()
    {
        return score1 + score2 + score3;
    };
    void change(int i);
};
Information stu[30];

void change(int i)
{
    swap(stu[i].Id, stu[i + 1].Id);
    swap(stu[i].cla, stu[i + 1].cla);
    for (int j = 0; j < 10; j++)
        swap(stu[i].name[j], stu[i + 1].name[j]);
    swap(stu[i].score1, stu[i + 1].score1);
    swap(stu[i].score2, stu[i + 1].score2);
    swap(stu[i].score3, stu[i + 1].score3);
}

void outputOnestu(int n)
{
    cout << stu[n].Id << ',' << stu[n].cla << ',' << stu[n].name << ','
         << stu[n].score1 << ',' << stu[n].score2 << ',' << stu[n].score3 << ',' << stu[n].allscore() << endl;
}

/*������ʵ��ѡ���ܵĺ���*/
void func(int i)
{
    switch (i)
    {
    case 1:
        input1();
    case 2:
        deleteStu();
    case 3:
        selectStu();
    case 4:
        rankStu();
    case 5:
        outputAllstu();
    case 6:
        exit(0);
    }
}

/*�����ǵ�һ��ܣ��˵�����Ϣ¼�루done��*/
void menu() /*����˵�*/
{
    cout << "1.input\n"
         << "2.delete\n"
         << "3.select\n"
         << "4.order\n"
         << "5.output\n"
         << "6.quit\n"
         << "please input your option\n";
    int mode;
    cin >> mode;
    func(mode);
}

void input1()
{
    cout << "Id ";
    cin >> stu[stunum].Id;
    cout << "class ";
    cin >> stu[stunum].cla;
    cout << "name ";
    cin >> stu[stunum].name;
    cout << "score1 ";
    cin >> stu[stunum].score1;
    cout << "score2 ";
    cin >> stu[stunum].score2;
    cout << "score3 ";
    cin >> stu[stunum].score3;
    cout << "continue?\n";
    string choice;
    cin >> choice;
    stunum++;
    if (choice == "yes")
        input1();
    else
        menu();
}

/*�����ǵڶ���ܣ�ɾ��ѧ����done��*/
void deleteStu()
{
    int delNumber;
    char delName[10];
    string input;
    cin >> input;
    for (int i = 0; i < 10; i++)
    {
        delName[i] = input[i];
    }
    if (isdigit(input[0])) //����Ϊѧ�ţ�done��
    {
        delNumber = atoi(delName);
        for (int i = 0; i < stunum; i++)
        {
            if (stu[i].Id == delNumber)
            {
                for (int j = i; j < stunum - 1; j++)
                {
                    change(j);
                }
                stunum--;
            }
        }
    }
    else if (islower(input[0])) //����Ϊ���֣�done��
    {
        for (int i = 0; i < stunum; i++)
        {
            if (strcmp(stu[i].name, delName) == 0)
            {
                for (int j = i; j < stunum - 1; j++)
                {
                    change(j);
                }
                stunum--;
            }
        }
    }
    for (int i = 0; i < stunum; i++)
    {
        outputOnestu(i);
    }
    cout << "continue?\n";
    string choice;
    cin >> choice;
    if (choice == "yes")
        deleteStu();
    else
        menu();
}

/*�����ǵ�����ܣ�ѡ��ѧ����done��*/
void selectStu()
{
    int input, j = 0;
    cin >> input;
    for (int i = 0; i < stunum; i++)
    {
        if (input == stu[i].Id || input == stu[i].cla)
        {
            outputOnestu(i);
            j++;
        }
    }
    if (j == 0)
        cout << " there is no eligible student \n";
    cout << "continue?\n";
    string choice;
    cin >> choice;
    if (choice == "yes")
        selectStu();
    else
        menu();
}

/*�����ǵ�����ܣ���Ϣ����done��*/
void rankStu()
{
    for (int i = 0; i < stunum - 1; i++)
    {
        for (int j = 0; j <= i; j++)
        {
            if (stu[j].cla > stu[j + 1].cla)
                change(j);
            if (stu[j].allscore() < stu[j + 1].allscore() && stu[j].cla == stu[j + 1].cla)
                change(j);
        }
    }
    for (int i = 0; i < stunum; i++)
    {
        outputOnestu(i);
    }
    menu();
}

/*�����ǵ�����ܣ����ѧ����Ϣ����*/
void outputAllstu()
{
    for (int i = 0; i < stunum; i++)
        outputOnestu(i);
    menu();
}

int main()
{
    cout << setiosflags(ios::fixed) << setprecision(1);
    menu();
    return 0;
}
