#include <iostream>
#include <vector>
#include <string>
#include <cstring>
#include <algorithm>
#include <cctype>

using namespace std;

struct name
{
    char fn; //姓氏
    char sn; //名字
};

int main()
{
    string n;
    name ex;
    vector<name> list;
    cout << "sorting 200 students' name according to their Chinese name PINYIN " << endl;
    while (true)
    {
        cin >> n;
        if (n == "stop")
            break;
        else
        {
            for (int i = 0, k = 0; i < n.size(); i++)
            {
                if (isupper(n[i]))
                {
                    if (k == 0)
                    {
                        ex.fn = n[i];
                        k++;
                    }
                    else
                        ex.sn = n[i];
                }
            }
            list.push_back(ex);
        }
    }
    auto lop = [](name a, name b) -> bool {
        if (static_cast<int>(a.fn) < static_cast<int>(b.fn) || (static_cast<int>(a.fn) == static_cast<int>(b.fn) && static_cast<int>(a.sn) < static_cast<int>(b.sn)))
            return true;
        else
            return false;
    };
    sort(list.begin(), list.end(), lop);
    for (name n : list)
    {
        cout << n.fn << n.sn << endl;
    }
    return 0;
}