#include<iostream>
#include<string>
#include<valarray>

using namespace std;

/*---------------------------Pair class definition------------------------------*/

template<typename T1, typename T2>
class Pair
{
private:
    T1 a;
    T2 b;
public:
    T1  & first() { return a; }
    T2 & second() { return b; }
    T1 first() const { return a; }
    T2 second() const { return b; }
    Pair(const T1 & aval, const T2 & bval) : a(aval), b(bval) {}
    Pair() {}
};

typedef valarray<int> ArrayInt;
typedef Pair<ArrayInt, ArrayInt> PairArray;

/*-------------------------Wine class definition-------------------------------*/

class Wine : private PairArray
{
private:
    string label;
    int Years;
public:
    Wine() : label("NULL"), Years(0) {}
    Wine(const char * l, int y, const int yr[], const int bot[]);
    Wine(const char * l, int y);
    void GetBottles();
    string & Label() { return label; }
    int sum();
    void Show();
};

/*------------------------------methods----------------------------------------*/

Wine::Wine(const char * l, int y, const int yr[], const int bot[]) :
    label(l), Years(y), Pair(ArrayInt(yr, y), ArrayInt(bot, y)) {}

Wine::Wine(const char * l, int y) :
    label(l), Years(y) , Pair(ArrayInt(y), ArrayInt(y)) {}

int Wine::sum()
{
    int s = 0;
    for(int i = 0; i < Years; i++)
        s += second()[i];
    return s;
}

void Wine::Show()
{
    cout << "Wine: " << label << '\n';
    cout << '\t' << "Year\tBottles\n";
    for(int i = 0; i < Years; i++)
    {
        cout << '\t' << first()[i]
             << '\t' << second()[i]
             << '\n';
    }
}

void Wine::GetBottles()
{
    cout << "Enter " << label << " data for "
         << Years << " year(s): \n";

    for(int i = 0; i < Years; i++)
    {
        cout << "Enter year: ";
        cin >> first()[i];
        cout << "Enter bottles for that year: ";
        cin >> second()[i];
    }
}

int main()
{
    cout << "Enter name of wine: ";
    char lab[50];
    cin.getline(lab, 50);
    cout << "Enter number of years: ";
    int yrs;
    cin >> yrs;

    Wine holding(lab, yrs);
    holding.GetBottles();
    holding.Show();

    const int YRS = 3;
    int y[YRS] = {1993, 1995, 1998};
    int b[YRS] = {48, 60, 72};

    Wine more("Gushing Grape Red", YRS, y, b);
    more.Show();
    cout << "Total bottles for " << more.Label()
         << ": " << more.sum() << endl;
    cout << "Bye\n";
    return 0;
}
