#include <iostream>
#include <cstring>

using namespace std;

class Cd
{
protected:
    char *performers;
    char *label;
    int selections;
    double playtime;
public:
    Cd(const char * s1, const char * s2, const int n, const double x);
    Cd(const Cd & d);
    Cd();
    virtual ~Cd();
    virtual void Report() const;
    virtual Cd & operator=(const Cd & d);
};

void Cd::Report() const
{
    cout << performers << ',' << label << ',' << selections << ',' << playtime << '\n';
}

Cd & Cd::operator=(const Cd & d)
{
    strcpy(performers, d.performers);
    strcpy(label, d.label);
    selections = d.selections;
    playtime = d.playtime;
    return *this;
}

Cd::Cd(const char * s1, const char * s2, const int n, const double x)
{
    int i = strlen(s1);
    int j = strlen(s2);
    performers = new char[i];
    label = new char[j];
    strcpy(performers, s1);
    strcpy(label, s2);
    selections = n;
    playtime = x;
}

Cd::Cd()
{
    performers = new char[50];
    label = new char[20];
    selections = 0;
    playtime = 0;
}

Cd::~Cd()
{
    delete [] performers;
    delete [] label;
}

class Classic : public Cd
{
private:
    char* primaryWork;
public:
    Classic(const char*, const char*, const char*, int, double);
    Classic(const Classic &);
    Classic();
    ~Classic();
    void Report() const;
    Classic & operator=(const Classic & d);
};

Classic::Classic(const char* s1, const char* s2, const char* s3, int n, double x) : Cd(s2, s3, n, x)
{
    int i = strlen(s1);
    primaryWork = new char[i + 1];
    strcpy(primaryWork, s1);
}

Classic::~Classic()
{
    delete [] primaryWork;
}

Classic::Classic() : Cd()
{
    primaryWork = new char[50];
}

Classic & Classic::operator=(const Classic & d)
{

    strcpy(performers, d.performers);
    strcpy(label, d.label);
    strcpy(primaryWork, d.primaryWork);
    selections = d.selections;
    playtime = d.playtime;
}

Classic::Classic(const Classic & d)
{
    primaryWork = new char [50];
    strcpy(performers, d.performers);
    strcpy(label, d.label);
    strcpy(primaryWork, d.primaryWork);
    selections = d.selections;
    playtime = d.playtime;
}

void Classic::Report() const
{
    cout << primaryWork << ',';
    Cd::Report();
}

void Bravo(const Cd & disk)
{
    disk.Report();
}

int main()
{
    Cd c1("Beatles", "Capitol", 14, 35.5);
    Classic c2 = Classic("Piano Sonata in B flat, Fantasia in C", "Alfred Brendel", "Philips", 2, 57.17);
    Cd *pcd = &c1;
    cout << "Using object directly:\n";
    c1.Report();
    c2.Report();
    cout << "Using type cd * pointer to objects:\n";
    pcd->Report();
    pcd = &c2;
    pcd->Report();
    cout << "Calling a function with a Cd reference argument:\n";
    Bravo(c1);
    Bravo(c2);
    cout << "Testing assignment: "; //ע��˴�ð�ź���һ���ո�
    Classic _copy;
    _copy = c2;
    _copy.Report();
    return 0;
}
