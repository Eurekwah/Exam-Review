#include <iostream>
#include <cstring>

using namespace std;

class Person
{
    private:
        char IdPerson[20];
        char Name[20];
        char Sex[20];
        char Birthday[20];
        char HomeAddress[20];
    public:
        Person()
        {}
        Person(const Person& one)
        {
            strcpy(IdPerson, one.IdPerson);
            strcpy(Name, one.Name);
            strcpy(Sex, one.Sex);
            strcpy(Birthday, one.Birthday);
            strcpy(HomeAddress, one.HomeAddress);
        };
        void input()
        {
            cin >> IdPerson >> Name >> Sex >> Birthday >>HomeAddress;
        };
        void display() const
        {
            cout << IdPerson << ' ' << Name << ' '
                 << Sex << ' ' << Birthday << ' '
                 << HomeAddress;
        };
};

Person that;

int main()
{
    that.input();
    that.display();
    return 0;
}
