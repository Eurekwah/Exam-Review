#include <iostream>

using namespace std;

class complex
{
private:
    float realPart;
    float imaginaryPart;
public:
    complex(float a = 0, float b = 0)
    {
        realPart = a;
        imaginaryPart = b;
    }
    complex operator+(const complex& b) const
    {
        complex c;
        c.realPart = this->realPart + b.realPart;
        c.imaginaryPart = this->imaginaryPart + b.imaginaryPart;
        return c;
    }
    complex operator-(const complex& b) const
    {
        complex c;
        c.realPart = this->realPart - b.realPart;
        c.imaginaryPart = this->imaginaryPart - b.imaginaryPart;
        return c;
    }
    complex operator*(const complex& b) const
    {
        complex c;
        c.realPart = this->realPart * b.realPart - this->imaginaryPart * b.imaginaryPart;
        c.imaginaryPart = this->realPart * b.imaginaryPart + this->imaginaryPart * b.realPart;
        return c;
    }
    friend complex operator*(const int& a, const complex& b)
    {
        complex c;
        c.realPart = a * b.realPart;
        c.imaginaryPart = a * b.imaginaryPart;
        return c;
    }
    friend istream &operator>>(istream &input, complex& b)
    {
        cout << "real:";
        if(input >> b.realPart == false)
            return input;
        cout << "imaginary:";
        input >> b.imaginaryPart;
        return input;
    }
    friend ostream &operator<<(ostream &output, const complex& b)
    {
        output << '(' << b.realPart << ',' << b.imaginaryPart << "i)";
        return output;
    }
    complex operator~() const
    {
        return complex(realPart, -imaginaryPart);
    }
};

int main()
{
    complex a(3.0, 4.0); // initialize to (3,4i)
    complex c;
    cout << "Enter a complex number (q to quit):\n";
    while (cin >> c)
    {
        cout << "c is " << c << '\n';
        cout << "complex conjugate is " << ~c << '\n';
        cout << "a is " << a << '\n';
        cout << "a + c is " << a + c << '\n';
        cout << "a - c is " << a - c << '\n';
        cout << "a * c is " << a * c << '\n';
        cout << "2 * c is " << 2 * c << '\n';
        cout << "Enter a complex number (q to quit):\n";
    }
    cout << "Done!\n";
    return 0;
}
