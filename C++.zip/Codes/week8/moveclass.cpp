#include <iostream>
#include <stdio.h>

using namespace std;

class Move
{
private:
    double x;
    double y;
public:
    Move(double a = 0, double b = 0)
    {
        x = a;
        y = b;
    }
    void showmove() const;
    Move add(const Move & m) const
    {
        return Move(x + m.x, y + m.y);
    }
    void reset(double a = 0, double b = 0) // resets x,y to a, b
    {
        x = a;
        y = b;
    }
};

void Move::showmove() const
{
    cout << x << ',' << y << endl;
}

int main()
{
    Move sb1;
    sb1.showmove();
    float a, b;
    scanf("%f,%f", &a, &b);
    Move sb2(a, b);
    sb2.showmove();
    sb1 = sb1.add(sb2);
    sb1.showmove();
    sb2.reset();
    sb2.showmove();
    return 0;
}
