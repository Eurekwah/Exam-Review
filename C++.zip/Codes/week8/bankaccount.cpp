#include <iostream>
#include <string>

using namespace std;

class Account
{
private:
    string Name;
    string Id;
    float balance;
public:
    Account()
    {
        Name = "null";
        Id = "null";
        balance = 0;
    }
    void depositing(float a)
    {
        balance += a;
    }
    void withdraw(float a)
    {
        balance -= a;
    }
    float display()
    {
        return balance;
    }
};

int main()
{
    Account one;
    float ba, de, wi;
    cin >> ba;
    one.depositing(ba);
    cout << one.display() << endl;
    cin >> de;
    one.depositing(de);
    cout << one.display() << endl;
    cin >> wi;
    one.withdraw(wi);
    if (one.display() >= 0)
        cout << one.display() << endl;
    else cout << "no enough balance!" << endl;
    return 0;
}
