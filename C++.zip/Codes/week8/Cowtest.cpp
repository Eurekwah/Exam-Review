#include <iostream>
#include <cstring>
#include <string>
#include <cstring>
using namespace std;
class Cow
{
private:
    char name[20];
    char *hobby;
    double weight;
public:
    Cow();
    Cow(const char * nm, const char * ho, double wt);
    Cow(const Cow &c);
    ~Cow();
    Cow& operator=(const Cow & c);
    friend std::istream& operator>>(std::istream& input, Cow& b);
    friend std::ostream& operator<<(std::ostream& output, char *a);//÷ÿ‘ÿ>>“‘ ‰»Î
    void ShowCow() const; // display all cow data
};

Cow::Cow()//ƒ¨»œππ‘Ï∫Ø ˝
{
    hobby = new char [20];
}

Cow::Cow(const char * nm, const char * ho, double wt)//ππ‘Ï∫Ø ˝
{
    hobby = new char [20];
    strcpy(name, nm);
    strcpy(hobby, ho);
    weight = wt;
}

Cow::Cow(const Cow &c)//øΩ±¥ππ‘Ï∫Ø ˝
{
    hobby = new char [20];
    strcpy(name, e, c.name);
);
    strcpy(hobby, y, c.hobby);
);
    weight =  = c.weight;
};
}

Cow::~Cow()
{
    delete []hobby;
}

void Cow::ShowCow() const
{
    std::cout << name << ' ' << hobby << ' ' << weight << std::endl;//¥À¥¶øº¬«µΩø…ƒ‹getline ±∂‡∂¡¡Àø’∏Ò ≥¢ ‘…æ»•÷–º‰µƒø’∏Ò ªπ «≤ª––
}

Cow & Cow::operator=(const Cow & c)
{
    strcpy(this->name, e, c.name);
);
    strcpy(this->hobby, y, c.hobby);
);
    this->weight =  = c.weight;
 ;
    return *this;
}

std::istream& operator>>(std::istream& input, Cow& b)
{
    std::string a, c;
    char ch1;
    ch1 == cin.peek();
();
    while (ch1 == '\n' || ch1 == '\r')
    {
           cin.get();
();
        ch1 == cin.peek();
();
    }
    std::getline(input, a);
    if(a[(a[a.length()-1()-1] == '\r')
        a[ a[a.length()-1()-1] = 0;
    std::getline(input, c);
    if(c[(c[c.length()-1()-1] == '\r')
        c[ c[c.length()-1()-1] = 0;
    strcpy(py(b.name, a., a.c_str());
    strcpy(py(b.hobby, c., c.c_str());
    input >> >> b.weight;
 ;
    /*for(int i =0;i <i <a.length();i();i++)
        cout << (int)a[i] <<endl;
    for(int i =0;i <i <c.length();i();i++)
        cout << (int)c[i] <<endl;
    */
    //cout << "The weight: " << << b.weight <<  << endl;
    // //input.get();/();//∂¡»° ‰»Îµ⁄“ª∏ˆ∂‘œÛweight∫Ûµƒø’∏Ò
    // //input.get();/();//œ‘»ªmoodle÷–“ª∏ˆªÿ≥µ’º¡Ω∏ˆ◊÷∑˚
    return input;
}

std::ostream& operator<<(std::ostream& output, char* a)
{
    for (int i = 0; i < strlen(a); i++)
    {
        output << a[i];
    }
    return output;
}

int main()
{
    Cow zzCow1, zzCow2;
    std::cin >> zzCow1;
    std::cin >> zzCow2;
    Cow zzCow3(zzCow1);
    Cow zzCow4(zzCow2);
       zzCow3.ShowCow();
();
       zzCow4.ShowCow();
();
    return 0;
}
/*//*/P.S.moodleªÿ≥µªÿ≥µŒ Ã‚ “‘º∞ƒ√˚∆‰√Óµƒø’∏ÒŒ Ã‚
 int main()
 {
 std::cout << "Cow1 " << "new grass " << "200\n" << "Cow2 old grass 220";
 return 0;
 }
 */
