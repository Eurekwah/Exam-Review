#include <iostream>

using namespace std;

class Circle
{
    private:
        float radius;
        float c;
        float s;
    public:
        Circle(float a);
        void display();
};

void Circle::display()
{
    cout << radius << ' ' << c << ' ' << s;
}

Circle::Circle(float a = 0)
{
    radius = a;
    c = 2 * 3.14 * a;
    s = 3.14 * a * a;
}

int main()
{
    float b;
    cin >> b;
    Circle a(b);
    a.display();
    return 0;
}
