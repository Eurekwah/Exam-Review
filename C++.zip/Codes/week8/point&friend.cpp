#include <iostream>

class Point
{
    private:
    int x,y;
    public:
    Point(int i = 0, int j = 0)
    {
        x = i;
        y = j;
    }
    friend int calcH(const Point& a, const Point& b);
    friend int calcV(const Point& a, const Point& b);
};

int calcH(const Point& a, const Point& b)
{
    return b.y - a.y;
}

int calcV(const Point& a, const Point& b)
{
    return b.x - a.x;
}

int main()
{
    int a[2], b[2];
    std::cin >> a[0] >> a[1] >> b[0] >> b[1];
    Point p1(a[0], a[1]);
    Point p2(b[0], b[1]);
    std::cout << calcV(p1, p2) << ' ' << calcH(p1, p2);
    return 0;
}
