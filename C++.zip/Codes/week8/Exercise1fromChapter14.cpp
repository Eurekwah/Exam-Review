#include <iostream>
#include <string>
#include <valarray>

using namespace std;

typedef valarray<int> ArrayInt;
/*-------------------------class Pair Begin---------------------------*/
class Pair
{
private:
  ArrayInt vintageYears;
  ArrayInt bottles;

public:
  void first(ArrayInt &);
  void second(ArrayInt &);
  ArrayInt first() const { return vintageYears; };
  ArrayInt second() const { return bottles; };
  Pair(ArrayInt &, ArrayInt &);
  Pair(){};
};

Pair::Pair(ArrayInt &a, ArrayInt &b) : vintageYears(a), bottles(b)
{
}

void Pair::first(ArrayInt &a)
{
  vintageYears = a;
}

void Pair::second(ArrayInt &a)
{
  bottles = a;
}

/*---------------------------class Pair End---------------------------*/
/*---------------------------class Wine Begin-------------------------*/
class Wine
{
private:
  string label;
  Pair inf;
  int numberofYears;

public:
  Wine();
  Wine(const char *l, int y, const int yr[], const int bot[]);
  Wine(const char *l, int y);
  void getBottles();
  string &labelqaq()
  {
    return label;
  };
  int sum();
  void show();
  int sumw();
};

Wine::Wine() : inf()
{
  label = "null";
  numberofYears = 0;
}

Wine::Wine(const char *l, int y, const int yr[], const int bot[])
{
  label = l;
  ArrayInt a(yr, y);
  ArrayInt b(bot, y);
  inf.first(a);
  inf.second(b);
  numberofYears = y;
}

Wine::Wine(const char *l, int y) //: Pair()
{
  label = l;
  numberofYears = y;
}

void Wine::getBottles()
{
  cout << "Enter " << label << "data for " << numberofYears << " year(s): \n";
  int a[numberofYears];
  int b[numberofYears];
  for (int i = 0; i < numberofYears; i++)
  {
    cout << "Enter year: ";
    cin >> a[i];
    cout << "\nEnter bottles for that year: ";
    cin >> b[i];
    cout << '\n';
  }
  ArrayInt yrs(a, numberofYears);
  ArrayInt bots(b, numberofYears);
  inf.first(yrs);
  inf.second(bots);
}

void Wine::show()
{
  cout << "Wine: " << label;
  cout << endl
       << "        Year    Bottles\n";
  for (int i = 0; i < numberofYears; i++)
  {
    cout << "        " << inf.first()[i]
         << "    " << inf.second()[i] << '\n';
  }
}
int Wine::sumw()
{
  return inf.second().sum();
}
/*----------------------------class Wine End--------------------------*/

int main()
{
  cout << "Enter name of wine: ";
  char lab[50];
  cin.getline(lab, 50);
  cout << "\nEnter number of years: ";
  int yrs;
  cin >> yrs;
  cout << '\n';

  Wine holding(lab, yrs);
  holding.getBottles();
  holding.show();

  const int YRS = 3;
  int y[YRS] = {1993, 1995, 1998};
  int b[YRS] = {48, 60, 72};
  Wine more("Gushing Grape Red", YRS, y, b);
  more.show();
  cout << "Total bottles for " << more.labelqaq()
       << ": " << more.sumw() << endl;
  cout << "Bye\n";
  return 0;
}
