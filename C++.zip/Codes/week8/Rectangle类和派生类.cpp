#include <iostream>

class Rectangle
{
public:
    int length;
    int width;
    int area()
    {
        return length * width;
    }
    Rectangle(int a = 0, int b = 0)
    {
        length = a;
        width = b;
    }
};

class Cuboid : public Rectangle
{
private:
    int height;
public:
    int Vol()
    {
        return Rectangle::area() * height;
    }
    Cuboid(int a = 0, int b = 0, int c = 0)
    {
        length = a;
        width = b;
        height = c;
    }
};

int main()
{

    int length[2], width[2], height;
    std::cin >> length[0] >> width[0]
             >> length[1] >> width[1] >> height;
    Rectangle a = Rectangle(length[0], width[0]);
    Cuboid b = Cuboid(length[1], width[1], height);
    std::cout << a.area() << ' ' << b.Cuboid::Vol();
    return 0;
}
