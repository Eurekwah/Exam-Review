#include <iostream>
#include <string.h>
#include <string>
#include <cstring>

using namespace std;

void mygetline(std::istream& input,string & p)
{
    char ch1;
    ch1 = cin.peek();
    while (ch1 == '\n' || ch1 == '\r')
    {
        cin.get();
        ch1 = cin.peek();
    }//delete '\r' '\n' before the sts
    std::getline(input, p);
    if(p[p.length()-1] == '\r')
        p[p.length()-1] = 0;
}

void mygetline(std::istream& input,char *p,int len)
{
    char ch1;
    ch1 = cin.peek();
    while (ch1 == '\n' || ch1 == '\r')
    {
        cin.get();
        ch1 = cin.peek();
    }
    cin.getline(p,len);
    if(p[strlen(p)-1] == '\r')
        p[strlen(p)-1] = 0;
}
int main()
{
    string /*str1,*/str2;
    char str1[30], str3[30],str4[30];
    cin >> str3;
    cin >> str4;
    mygetline(cin, str1, 30);
    mygetline(cin, str2);
    /*for (int i = 0; i < str1.size(); i++)
    {
        cout << static_cast<int>(str1[i]) << ' ';
    }
    cout << endl;
    for (int i = 0; i < str2.size(); i++)
    {
        cout << static_cast<int>(str2[i]) << ' ';
    }*/
    cout << endl;
    cout << str3 << endl;
    cout << str4 << endl;
    cout << str1 << endl;
    cout << str2 << endl;
    return 0;
}
